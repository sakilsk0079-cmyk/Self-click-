package com.example.unityadstestconsole

import android.content.Context
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.Network
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsExperimental
import com.unity3d.ads.InitializationConfiguration
import com.unity3d.ads.InitializationListener
import com.unity3d.ads.LoadConfiguration
import com.unity3d.ads.ShowConfiguration
import com.unity3d.ads.InterstitialAd
import com.unity3d.ads.RewardedAd
import com.unity3d.ads.InterstitialShowListener
import com.unity3d.ads.RewardedShowListener
import com.unity3d.ads.ShowFinishState
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Unity Ads Test Console
 * - TEST_MODE stays true by design.
 * - Replace the Game ID and placement IDs with values from your own Unity Dashboard.
 * - Never click your own production ads or generate artificial impressions.
 * - TOTAL_ADS is saved on the device and only increases when the SDK reports a completed ad.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        private const val GAME_ID_ANDROID = "800428413"
        private const val TEST_MODE = true
        private const val INTERSTITIAL_PLACEMENT = "BP_Interstitial_Android"
        private const val REWARDED_PLACEMENT = "BP_Rewarded_Android"

        private const val PREFS = "unity_console_stats"
        private const val KEY_TOTAL_ADS = "total_ads"

        private const val BG = 0xFF07080D.toInt()
        private const val PANEL = 0xFF0F1124.toInt()
        private const val RED = 0xFFFF3159.toInt()
        private const val GREEN = 0xFF36D995.toInt()
        private const val PURPLE = 0xFFB64DFF.toInt()
        private const val CYAN = 0xFF45D9FF.toInt()
        private const val GOLD = 0xFFFFD36B.toInt()
        private const val ORANGE = 0xFFFF9A3C.toInt()
        private const val BLUE = 0xFF5B9DFF.toInt()
        private const val LIME = 0xFFB6F24A.toInt()
        private const val PINK = 0xFFFF4DDB.toInt()
        private const val WHITE = 0xFFFFFFFF.toInt()
        private const val MUTED = 0xFF8C91A5.toInt()
        private const val STAMP = 0xFF6F7690.toInt()
    }

    private class Seg(val text: String, val color: Int)

    private val mainHandler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var terminalText: TextView
    private lateinit var terminalScroll: ScrollView
    private lateinit var ipValue: TextView
    private lateinit var countryValue: TextView
    private lateinit var placementValue: TextView
    private lateinit var adsValue: TextView
    private lateinit var durationValue: TextView
    private lateinit var sdkStatusLabel: TextView
    private lateinit var interstitialBtn: Button
    private lateinit var rewardedBtn: Button

    private var totalCompletedAds = 0
    private var sessionStartedAt = System.currentTimeMillis()
    private var initialized = false
    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null
    private var interstitialLoading = false
    private var rewardedLoading = false
    private val logLines = mutableListOf<List<Seg>>()
    private var lastIp: String? = null
    @Volatile private var fetching = false
    private var netCallback: ConnectivityManager.NetworkCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = 0

        totalCompletedAds = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_TOTAL_ADS, 0)

        setContentView(buildDashboard())
        adsValue.text = totalCompletedAds.toString()
        updateButtons()

        logCmd("termux-setup-session")
        log(Seg("APP_STARTED", GREEN))
        log(Seg("SAVED_STATS_LOADED : ", GREEN), Seg("$totalCompletedAds ads from previous sessions", CYAN))
        logCmd("device-info --local")
        logKV("MODEL", "${Build.MANUFACTURER.uppercase(Locale.US)} ${Build.MODEL}", WHITE)
        logKV("BRAND", Build.BRAND.uppercase(Locale.US), CYAN)
        logKV("ANDROID", Build.VERSION.RELEASE, BLUE)
        logKV("API", Build.VERSION.SDK_INT.toString(), PURPLE)
        logKV("BOARD", Build.BOARD, ORANGE)
        logCmd("fetching ip, geo, isp ...")
        fetchIpLocation()
        initializeUnityAds()
        registerNetworkWatcher()
        mainHandler.postDelayed(object : Runnable {
            override fun run() {
                fetchIpLocation()
                mainHandler.postDelayed(this, 60_000L)
            }
        }, 60_000L)

        mainHandler.post(object : Runnable {
            override fun run() {
                val elapsed = (System.currentTimeMillis() - sessionStartedAt) / 1000
                val h = elapsed / 3600
                val m = (elapsed % 3600) / 60
                val s = elapsed % 60
                durationValue.text = String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
                mainHandler.postDelayed(this, 1000)
            }
        })
    }

    private fun buildDashboard(): View {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(24))
        }
        scroll.addView(root)

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(0xFF13090E.toInt(), RED, 22)
            setPadding(dp(16), dp(18), dp(14), dp(18))
        }
        header.addView(label("UNITY_ADS_TEST_CONSOLE", RED, 15f, true), LinearLayout.LayoutParams(0, -2, 1f))
        val edit = label("⚙ EDIT", GOLD, 13f, true).apply {
            background = rounded(0xFF211B10.toInt(), 0xFF66552B.toInt(), 14)
            setPadding(dp(12), dp(9), dp(12), dp(9))
            setOnClickListener {
                log(Seg("CONFIG: Edit GAME_ID and placement IDs in MainActivity.kt", GOLD))
            }
        }
        header.addView(edit)
        sdkStatusLabel = label("  SDK: INIT...", GOLD, 12f, false)
        header.addView(sdkStatusLabel)
        root.addView(header, verticalParams(bottom = 12))

        // Row 1: DEVICE_MODEL + IP_ADDRESS
        val row1 = horizontalRow()
        row1.addView(infoCard("DEVICE_MODEL", Build.MODEL, RED), weightParams())
        ipValue = TextView(this)
        val ipCard = infoCard("IP_ADDRESS", "Fetching...", RED, ipValue)
        ipCard.setOnClickListener {
            log(Seg("IP_REFRESH_REQUESTED", GOLD))
            fetchIpLocation(manual = true)
        }
        row1.addView(ipCard, weightParams())
        root.addView(row1, verticalParams(bottom = 10))

        // Row 2: COUNTRY + GAME_ID
        val row2 = horizontalRow()
        countryValue = TextView(this)
        row2.addView(infoCard("COUNTRY", "Fetching...", GOLD, countryValue), weightParams())
        row2.addView(infoCard("GAME_ID", GAME_ID_ANDROID, GOLD, valueColor = GREEN), weightParams())
        root.addView(row2, verticalParams(bottom = 10))

        // Row 3: PLACEMENT + DURATION + TOTAL_ADS
        val row3 = horizontalRow()
        placementValue = TextView(this)
        row3.addView(infoCard("PLACEMENT", "Interstitial", MUTED, placementValue, textSp = 14f), weightParams(1.0f))
        durationValue = TextView(this)
        row3.addView(infoCard("DURATION", "00:00:00", MUTED, durationValue, textSp = 14f), weightParams(0.9f))
        adsValue = TextView(this)
        row3.addView(infoCard("TOTAL_ADS", "0", GREEN, adsValue, valueColor = WHITE), weightParams(0.7f))
        root.addView(row3, verticalParams(bottom = 12))

        // Terminal
        val terminal = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(PANEL, PURPLE, 25)
        }
        val termHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val r = dp(25).toFloat()
            background = GradientDrawable().apply {
                setColor(0xFF2B1141.toInt())
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        termHeader.addView(label("SYSTEM_TERMINAL // TEST_SESSION", WHITE, 13f, true), LinearLayout.LayoutParams(0, -2, 1f))
        termHeader.addView(label("•••", PINK, 16f, true))
        terminal.addView(termHeader, LinearLayout.LayoutParams(-1, -2))

        terminalText = label("", CYAN, 12.5f, false).apply {
            typeface = Typeface.MONOSPACE
            gravity = Gravity.TOP
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        terminalScroll = ScrollView(this).apply {
            addView(terminalText)
            isFillViewport = true
        }
        terminal.addView(terminalScroll, LinearLayout.LayoutParams(-1, dp(500)))
        root.addView(terminal, verticalParams(bottom = 14))

        // Buttons
        val adButtons = horizontalRow()
        interstitialBtn = actionButton("SHOW_INTERSTITIAL", GOLD) { showTestAd(INTERSTITIAL_PLACEMENT) }
        rewardedBtn = actionButton("SHOW_REWARDED", RED) { showTestAd(REWARDED_PLACEMENT) }
        adButtons.addView(interstitialBtn, LinearLayout.LayoutParams(0, dp(82), 1f).apply { rightMargin = dp(8) })
        adButtons.addView(rewardedBtn, LinearLayout.LayoutParams(0, dp(82), 1f).apply { leftMargin = dp(8) })
        root.addView(adButtons)

        root.addView(label("TEST MODE ENABLED • NO LIVE SELF-CLICKS", GREEN, 10f, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        })
        return scroll
    }

    // ---------- Logging ----------

    private fun log(vararg segs: Seg) {
        logLines.add(segs.toList())
        while (logLines.size > 150) logLines.removeAt(0)
        renderLog()
    }

    private fun logCmd(cmd: String) = log(Seg("$ ", GREEN), Seg(cmd, CYAN))

    private fun logKV(key: String, value: String, valueColor: Int) =
        log(Seg(key.padEnd(10), GOLD), Seg(": ", MUTED), Seg(value, valueColor))

    private fun renderLog() {
        if (!::terminalText.isInitialized) return
        val sb = SpannableStringBuilder()
        val stamp = java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(java.util.Date())
        for (line in logLines) {
            sb.appendColored("$stamp [-] ", STAMP)
            for (seg in line) sb.appendColored(seg.text, seg.color)
            sb.append("\n")
        }
        sb.appendColored("root@mod", GREEN)
        sb.appendColored(":~$ ", MUTED)
        sb.appendColored("▌", CYAN)
        terminalText.text = sb
        terminalScroll.post { terminalScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun SpannableStringBuilder.appendColored(text: String, color: Int) {
        val start = length
        append(text)
        setSpan(ForegroundColorSpan(color), start, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun sdkStatus(message: String, color: Int) {
        if (::sdkStatusLabel.isInitialized) {
            sdkStatusLabel.text = "  $message"
            sdkStatusLabel.setTextColor(color)
        }
        log(Seg(message, color))
    }

    private fun updateButtons() {
        if (!::interstitialBtn.isInitialized) return
        interstitialBtn.alpha = if (interstitialAd != null) 1f else 0.45f
        rewardedBtn.alpha = if (rewardedAd != null) 1f else 0.45f
    }

    private fun addCompletedAd() {
        totalCompletedAds++
        adsValue.text = totalCompletedAds.toString()
        getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putInt(KEY_TOTAL_ADS, totalCompletedAds).apply()
    }

    // ---------- Unity Ads ----------

    @OptIn(UnityAdsExperimental::class)
    private fun initializeUnityAds() {
        log(Seg("UNITY_ADS_INITIALIZING (TEST MODE)", GOLD))
        val config = InitializationConfiguration.Builder(GAME_ID_ANDROID)
            .withTestMode(TEST_MODE)
            .build()

        UnityAds.initialize(config, InitializationListener { error ->
            runOnUiThread {
                if (error == null) {
                    initialized = true
                    sdkStatus("SDK: READY", GREEN)
                    log(Seg("UNITY_ADS_INITIALIZED: SDK ${UnityAds.version}", GREEN))
                    loadInterstitial()
                    loadRewarded()
                } else {
                    initialized = false
                    sdkStatus("SDK: ERROR", RED)
                    log(Seg("UNITY_INIT_ERROR: ${error.code} / ${error.message}", RED))
                }
            }
        })
    }

    private fun loadInterstitial() {
        if (!initialized || interstitialLoading || interstitialAd != null) return
        interstitialLoading = true
        log(Seg("INTERSTITIAL_LOAD_REQUEST", CYAN))
        val config = LoadConfiguration.Builder(INTERSTITIAL_PLACEMENT).build()

        InterstitialAd.load(config) { ad, error ->
            runOnUiThread {
                interstitialLoading = false
                if (ad != null) {
                    interstitialAd = ad
                    log(Seg("INTERSTITIAL_READY", GREEN))
                } else {
                    log(Seg("INTERSTITIAL_LOAD_FAILED: ${error?.code} / ${error?.message}", RED))
                    scheduleRetry { loadInterstitial() }
                }
                updateButtons()
            }
        }
    }

    private fun loadRewarded() {
        if (!initialized || rewardedLoading || rewardedAd != null) return
        rewardedLoading = true
        log(Seg("REWARDED_LOAD_REQUEST", CYAN))
        val config = LoadConfiguration.Builder(REWARDED_PLACEMENT).build()

        RewardedAd.load(config) { ad, error ->
            runOnUiThread {
                rewardedLoading = false
                if (ad != null) {
                    rewardedAd = ad
                    log(Seg("REWARDED_READY", GREEN))
                } else {
                    log(Seg("REWARDED_LOAD_FAILED: ${error?.code} / ${error?.message}", RED))
                    scheduleRetry { loadRewarded() }
                }
                updateButtons()
            }
        }
    }

    private fun showTestAd(placementId: String) {
        if (!initialized) {
            log(Seg("BLOCKED: Unity Ads SDK is not initialized", RED))
            return
        }

        val showConfig = ShowConfiguration.Builder().build()

        if (placementId == INTERSTITIAL_PLACEMENT) {
            placementValue.text = "Interstitial"
            val ad = interstitialAd
            if (ad == null) {
                log(Seg("INTERSTITIAL_NOT_READY: loading", GOLD))
                loadInterstitial()
                return
            }
            interstitialAd = null
            updateButtons()
            log(Seg("INTERSTITIAL_SHOW_REQUEST", CYAN))
            ad.show(this, showConfig, object : InterstitialShowListener {
                override fun onStarted(unityAd: InterstitialAd) {
                    runOnUiThread { log(Seg("INTERSTITIAL_SHOW_STARTED", GREEN)) }
                }

                override fun onClicked(unityAd: InterstitialAd) {
                    runOnUiThread { log(Seg("INTERSTITIAL_CLICK_CALLBACK", MUTED)) }
                }

                override fun onCompleted(unityAd: InterstitialAd, state: ShowFinishState) {
                    runOnUiThread {
                        log(Seg("INTERSTITIAL_COMPLETED: $state", GREEN))
                        if (state == ShowFinishState.COMPLETED) addCompletedAd()
                        loadInterstitial()
                    }
                }

                override fun onFailed(unityAd: InterstitialAd, error: com.unity3d.ads.UnityAdsError) {
                    runOnUiThread {
                        log(Seg("INTERSTITIAL_SHOW_FAILED: ${error.code} / ${error.message}", RED))
                        loadInterstitial()
                    }
                }
            })
        } else if (placementId == REWARDED_PLACEMENT) {
            placementValue.text = "Rewarded"
            val ad = rewardedAd
            if (ad == null) {
                log(Seg("REWARDED_NOT_READY: loading", GOLD))
                loadRewarded()
                return
            }
            rewardedAd = null
            updateButtons()
            log(Seg("REWARDED_SHOW_REQUEST", CYAN))
            ad.show(this, showConfig, object : RewardedShowListener {
                override fun onStarted(unityAd: RewardedAd) {
                    runOnUiThread { log(Seg("REWARDED_SHOW_STARTED", GREEN)) }
                }

                override fun onClicked(unityAd: RewardedAd) {
                    runOnUiThread { log(Seg("REWARDED_CLICK_CALLBACK", MUTED)) }
                }

                override fun onCompleted(unityAd: RewardedAd, state: ShowFinishState) {
                    runOnUiThread {
                        log(Seg("REWARDED_COMPLETED: $state", GREEN))
                        if (state == ShowFinishState.COMPLETED) addCompletedAd()
                        loadRewarded()
                    }
                }

                override fun onFailed(unityAd: RewardedAd, error: com.unity3d.ads.UnityAdsError) {
                    runOnUiThread {
                        log(Seg("REWARDED_SHOW_FAILED: ${error.code} / ${error.message}", RED))
                        loadRewarded()
                    }
                }

                override fun onRewarded(unityAd: RewardedAd) {
                    runOnUiThread { log(Seg("REWARD_EARNED: verified SDK reward callback", GOLD)) }
                }
            })
        }
    }

    private fun scheduleRetry(task: () -> Unit) {
        mainHandler.postDelayed({
            if (!isFinishing && !isDestroyed) task()
        }, 15_000L)
    }

    // ---------- IP / geo (live) ----------

    private class GeoInfo(
        val ip: String,
        val country: String,
        val region: String,
        val city: String,
        val isp: String
    )

    /** Re-checks the IP when Wi-Fi/mobile data changes, so a new network shows its own IP. */
    private fun registerNetworkWatcher() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    mainHandler.postDelayed({ fetchIpLocation() }, 1500L)
                }
            }
            cm.registerDefaultNetworkCallback(cb)
            netCallback = cb
        } catch (e: Exception) {
            log(Seg("NETWORK_WATCH_UNAVAILABLE: ${e.javaClass.simpleName}", MUTED))
        }
    }

    private fun fetchIpLocation(manual: Boolean = false) {
        if (fetching) return
        fetching = true
        io.execute {
            val result = lookupIpapi() ?: lookupIpwho()
            fetching = false
            runOnUiThread {
                if (result == null) {
                    if (lastIp == null) {
                        ipValue.text = "Unavailable"
                        countryValue.text = "Unavailable"
                    }
                    log(Seg("IP_GEO_ERROR: lookup failed (check internet)", RED))
                    return@runOnUiThread
                }
                val changed = result.ip != lastIp
                ipValue.text = result.ip
                countryValue.text = result.country.uppercase(Locale.US)
                if (changed) {
                    if (lastIp != null) log(Seg("NETWORK_CHANGE_DETECTED", GOLD))
                    lastIp = result.ip
                    logCmd("network-info --ip")
                    logKV("IP", result.ip, CYAN)
                    logKV("COUNTRY", result.country.uppercase(Locale.US), GREEN)
                    logKV("STATE", result.region.uppercase(Locale.US), LIME)
                    logKV("CITY", result.city, PINK)
                    logKV("ISP", result.isp, ORANGE)
                    log(Seg("LOCATION_SOURCE: IP APPROXIMATION", MUTED))
                } else if (manual) {
                    log(Seg("IP_UNCHANGED: ${result.ip}", MUTED))
                }
            }
        }
    }

    private fun httpGetJson(url: String): JSONObject? {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                requestMethod = "GET"
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "UnityAdsTestConsole/1.0")
            }
            if (connection.responseCode !in 200..299) return null
            JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
        } catch (e: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }

    private fun lookupIpapi(): GeoInfo? {
        val j = httpGetJson("https://ipapi.co/json/") ?: return null
        if (j.optBoolean("error", false) || j.optString("ip").isBlank()) return null
        return GeoInfo(
            j.optString("ip"),
            j.optString("country_name", "Unavailable"),
            j.optString("region", "Unavailable"),
            j.optString("city", "Unavailable"),
            j.optString("org", "Unavailable")
        )
    }

    private fun lookupIpwho(): GeoInfo? {
        val j = httpGetJson("https://ipwho.is/") ?: return null
        if (!j.optBoolean("success", false) || j.optString("ip").isBlank()) return null
        return GeoInfo(
            j.optString("ip"),
            j.optString("country", "Unavailable"),
            j.optString("region", "Unavailable"),
            j.optString("city", "Unavailable"),
            j.optJSONObject("connection")?.optString("isp", "Unavailable") ?: "Unavailable"
        )
    }

    // ---------- UI helpers ----------

    private fun infoCard(
        title: String,
        value: String,
        accent: Int,
        valueView: TextView? = null,
        valueColor: Int = WHITE,
        textSp: Float = 16f
    ): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(0xFF111019.toInt(), accent, 18)
            setPadding(dp(13), dp(13), dp(10), dp(14))
        }
        box.addView(label(title, accent, 10f, false))
        val v = valueView ?: TextView(this)
        v.text = value
        v.setTextColor(valueColor)
        v.textSize = textSp
        v.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        box.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        return box
    }

    private fun actionButton(text: String, color: Int, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 11f
            setTextColor(color)
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(0xFF17121A.toInt(), color, 20)
            setOnClickListener { action() }
        }

    private fun label(text: String, color: Int, size: Float, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            setTextColor(color)
            textSize = size
            typeface = if (bold) Typeface.create("sans-serif", Typeface.BOLD) else Typeface.MONOSPACE
        }

    private fun horizontalRow() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun weightParams(weight: Float = 1f) =
        LinearLayout.LayoutParams(0, -2, weight).apply {
            marginEnd = dp(8)
        }

    private fun verticalParams(bottom: Int) =
        LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom) }

    private fun rounded(fill: Int, stroke: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(1), stroke)
        }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        super.onDestroy()
        try {
            netCallback?.let {
                (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager)
                    .unregisterNetworkCallback(it)
            }
        } catch (_: Exception) {}
        io.shutdownNow()
        mainHandler.removeCallbacksAndMessages(null)
    }
}
